🖨️ 3D Print Academy — Free Magnet Frame Starter Pack
=====================================================

Thanks for downloading! Here's what's included:

1. instax-mini-magnet-frame.stl — Fits Instax Mini photos
2. 4x6-magnet-frame.stl — Standard 4×6 photo size
3. heart-magnet-frame.stl — Heart-shaped frame
4. star-magnet-frame.stl — Star-shaped frame

PRINT SETTINGS (PLA recommended):
- Layer height: 0.2mm
- Infill: 20%
- Supports: None needed
- Magnets: 10mm × 2mm neodymium (N52 recommended)

FULL COURSE: https://ajayadesign.com/3D-print/#enroll
- 43 lessons, 15+ STL files with commercial license
- Live 1-on-1 mentorship
- Business launch training

Questions? Email aj@ajayadesign.com

Happy printing! 🎉
— AJ, 3D Print Academy
